"""
Data preprocessing and feature engineering for stroke prediction.
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import joblib
import os


class StrokeDataPreprocessor:
    """Handles all data preprocessing for stroke prediction."""
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.feature_names = None
        
    def preprocess(self, df, fit=True):
        """
        Preprocess the stroke dataset.
        
        Args:
            df: Raw dataframe
            fit: Whether to fit scalers (True for training, False for inference)
            
        Returns:
            Processed feature matrix and target (if available)
        """
        df = df.copy()
        
        # Handle missing BMI values with median
        if 'bmi' in df.columns:
            if fit:
                self.bmi_median = df['bmi'].median()
            df['bmi'] = df['bmi'].fillna(self.bmi_median)
        
        # Create age groups (clinical relevance)
        df['age_group'] = pd.cut(df['age'], 
                                  bins=[0, 50, 80, 120], 
                                  labels=[0, 1, 2])
        df['age_group'] = df['age_group'].astype(int)
        
        # BMI categories
        df['bmi_category'] = pd.cut(df['bmi'],
                                     bins=[0, 18.5, 25, 30, 100],
                                     labels=[0, 1, 2, 3])
        df['bmi_category'] = df['bmi_category'].astype(int)
        
        # Glucose level categories
        df['glucose_category'] = pd.cut(df['avg_glucose_level'],
                                         bins=[0, 100, 126, 300],
                                         labels=[0, 1, 2])
        df['glucose_category'] = df['glucose_category'].astype(int)
        
        # Encode categorical variables
        # Gender
        df['gender_encoded'] = df['gender'].map({
            'male': 1, 'Male': 1,
            'female': 0, 'Female': 0,
            'other': 2, 'Other': 2
        }).fillna(2)
        
        # Ever married
        df['ever_married_encoded'] = df['ever_married'].map({
            'yes': 1, 'Yes': 1,
            'no': 0, 'No': 0
        }).fillna(0)
        
        # Work type - one-hot encoding
        work_type_dummies = pd.get_dummies(df['work_type'], prefix='work')
        df = pd.concat([df, work_type_dummies], axis=1)
        
        # Residence type
        df['urban_residence'] = df['Residence_type'].map({
            'urban': 1, 'Urban': 1,
            'rural': 0, 'Rural': 0
        }).fillna(0)
        
        # Smoking status - one-hot encoding
        smoking_dummies = pd.get_dummies(df['smoking_status'], prefix='smoking')
        df = pd.concat([df, smoking_dummies], axis=1)
        
        # Select features for model
        feature_cols = [
            'age', 'hypertension', 'heart_disease', 'bmi', 'avg_glucose_level',
            'age_group', 'bmi_category', 'glucose_category',
            'gender_encoded', 'ever_married_encoded', 'urban_residence'
        ]
        
        # Add work type columns
        work_cols = [col for col in df.columns if col.startswith('work_')]
        feature_cols.extend(work_cols)
        
        # Add smoking columns
        smoking_cols = [col for col in df.columns if col.startswith('smoking_')]
        feature_cols.extend(smoking_cols)
        
        # Ensure all feature columns exist
        for col in feature_cols.copy():
            if col not in df.columns:
                feature_cols.remove(col)
        
        X = df[feature_cols].copy()
        
        # Store feature names
        if fit:
            self.feature_names = feature_cols
        
        # Scale numerical features
        numerical_cols = ['age', 'bmi', 'avg_glucose_level']
        if fit:
            X[numerical_cols] = self.scaler.fit_transform(X[numerical_cols])
        else:
            X[numerical_cols] = self.scaler.transform(X[numerical_cols])
        
        # Get target if available
        y = df['stroke'] if 'stroke' in df.columns else None
        
        return X, y
    
    def save(self, path='models/preprocessor.pkl'):
        """Save preprocessor state."""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        joblib.dump({
            'scaler': self.scaler,
            'feature_names': self.feature_names,
            'bmi_median': self.bmi_median
        }, path)
        
    def load(self, path='models/preprocessor.pkl'):
        """Load preprocessor state."""
        state = joblib.load(path)
        self.scaler = state['scaler']
        self.feature_names = state['feature_names']
        self.bmi_median = state['bmi_median']


def prepare_data(data_path='data/stroke-data.csv', test_size=0.2, random_state=42):
    """
    Load and prepare data for training.
    
    Returns:
        X_train, X_test, y_train, y_test, preprocessor
    """
    df = pd.read_csv(data_path)
    
    # Drop ID column
    if 'id' in df.columns:
        df = df.drop('id', axis=1)
    
    preprocessor = StrokeDataPreprocessor()
    X, y = preprocessor.preprocess(df, fit=True)
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    
    return X_train, X_test, y_train, y_test, preprocessor
